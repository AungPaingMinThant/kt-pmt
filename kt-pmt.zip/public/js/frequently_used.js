// Step 1
$(".timeline-badge-1").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".timeline-badge-1").addClass('active');
	$(".step_1").addClass('d-none');
	$(".step_1_1").removeClass('d-none');
});
$(".timeline-badge-2").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".timeline-badge-2").addClass('active');
	$(".step_1").addClass('d-none');
	$(".step_1_2").removeClass('d-none');
});
$(".timeline-badge-3").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".timeline-badge-3").addClass('active');
	$(".step_1").addClass('d-none');
	$(".step_1_3").removeClass('d-none');
});

// Step 2
$(".step_2_timeline-badge-1").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_2_timeline-badge-1").addClass('active');
	$(".step_2").addClass('d-none');
	$(".step_2_1").removeClass('d-none');
});
$(".step_2_timeline-badge-2").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_2_timeline-badge-2").addClass('active');
	$(".step_2").addClass('d-none');
	$(".step_2_2").removeClass('d-none');
});
$(".step_2_timeline-badge-3").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_2_timeline-badge-3").addClass('active');
	$(".step_2").addClass('d-none');
	$(".step_2_3").removeClass('d-none');
});
$(".step_2_timeline-badge-4").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_2_timeline-badge-4").addClass('active');
	$(".step_2").addClass('d-none');
	$(".step_2_4").removeClass('d-none');
});
$(".step_2_timeline-badge-5A").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_2_timeline-badge-5A").addClass('active');
	$(".step_2").addClass('d-none');
	$(".step_2_5A").removeClass('d-none');
});
$(".step_2_timeline-badge-5B").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_2_timeline-badge-5B").addClass('active');
	$(".step_2").addClass('d-none');
	$(".step_2_5B").removeClass('d-none');
});
$(".step_2_timeline-badge-6").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_2_timeline-badge-6").addClass('active');
	$(".step_2").addClass('d-none');
	$(".step_2_6").removeClass('d-none');
});

// Step 3
	$(".step_3_timeline-badge-1").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_3_timeline-badge-1").addClass('active');
	$(".step_3").addClass('d-none');
	$(".step_3_1").removeClass('d-none');
});
$(".step_3_timeline-badge-2").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_3_timeline-badge-2").addClass('active');
	$(".step_3").addClass('d-none');
	$(".step_3_2").removeClass('d-none');
});
$(".step_3_timeline-badge-3").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_3_timeline-badge-3").addClass('active');
	$(".step_3").addClass('d-none');
	$(".step_3_3").removeClass('d-none');
});
$(".step_3_timeline-badge-4A").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_3_timeline-badge-4A").addClass('active');
	$(".step_3").addClass('d-none');
	$(".step_3_4A").removeClass('d-none');
});
$(".step_3_timeline-badge-4B").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_3_timeline-badge-4B").addClass('active');
	$(".step_3").addClass('d-none');
	$(".step_3_4B").removeClass('d-none');
});
$(".step_3_timeline-badge-5").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_3_timeline-badge-5").addClass('active');
	$(".step_3").addClass('d-none');
	$(".step_3_5").removeClass('d-none');
});

// step 4
$(".step_4_timeline-badge-1").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_4_timeline-badge-1").addClass('active');
	$(".step_4").addClass('d-none');
	$(".step_4_1").removeClass('d-none');
});
$(".step_4_timeline-badge-2").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_4_timeline-badge-2").addClass('active');
	$(".step_4").addClass('d-none');
	$(".step_4_2").removeClass('d-none');
});
$(".step_4_timeline-badge-3").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_4_timeline-badge-3").addClass('active');
	$(".step_4").addClass('d-none');
	$(".step_4_3").removeClass('d-none');
});
$(".step_4_timeline-badge-4").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_4_timeline-badge-4").addClass('active');
	$(".step_4").addClass('d-none');
	$(".step_4_4").removeClass('d-none');
});
$(".step_4_timeline-badge-5A").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_4_timeline-badge-5A").addClass('active');
	$(".step_4").addClass('d-none');
	$(".step_4_5A").removeClass('d-none');
});
$(".step_4_timeline-badge-5B").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_4_timeline-badge-5B").addClass('active');
	$(".step_4").addClass('d-none');
	$(".step_4_5B").removeClass('d-none');
});
$(".step_4_timeline-badge-6").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_4_timeline-badge-6").addClass('active');
	$(".step_4").addClass('d-none');
	$(".step_4_6").removeClass('d-none');
});

// Step 5
$(".step_5_timeline-badge-1").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_5_timeline-badge-1").addClass('active');
	$(".step_5").addClass('d-none');
	$(".step_5_1").removeClass('d-none');
});
$(".step_5_timeline-badge-2").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_5_timeline-badge-2").addClass('active');
	$(".step_5").addClass('d-none');
	$(".step_5_2").removeClass('d-none');
});
$(".step_5_timeline-badge-3").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_5_timeline-badge-3").addClass('active');
	$(".step_5").addClass('d-none');
	$(".step_5_3").removeClass('d-none');
});

// Step 6
$(".step_6_timeline-badge-1").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_6_timeline-badge-1").addClass('active');
	$(".step_6").addClass('d-none');
	$(".step_6_1").removeClass('d-none');
});
$(".step_6_timeline-badge-2").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_6_timeline-badge-2").addClass('active');
	$(".step_6").addClass('d-none');
	$(".step_6_2").removeClass('d-none');
});
$(".step_6_timeline-badge-3").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_6_timeline-badge-3").addClass('active');
	$(".step_6").addClass('d-none');
	$(".step_6_3").removeClass('d-none');
});
$(".step_6_timeline-badge-4").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_6_timeline-badge-4").addClass('active');
	$(".step_6").addClass('d-none');
	$(".step_6_4").removeClass('d-none');
});

// Step 7
$(".step_7_timeline-badge-1").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_7_timeline-badge-1").addClass('active');
	$(".step_7").addClass('d-none');
	$(".step_7_1").removeClass('d-none');
});
$(".step_7_timeline-badge-2").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_7_timeline-badge-2").addClass('active');
	$(".step_7").addClass('d-none');
	$(".step_7_2").removeClass('d-none');
});
$(".step_7_timeline-badge-3").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_7_timeline-badge-3").addClass('active');
	$(".step_7").addClass('d-none');
	$(".step_7_3").removeClass('d-none');
});
$(".step_7_timeline-badge-4").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_7_timeline-badge-4").addClass('active');
	$(".step_7").addClass('d-none');
	$(".step_7_4").removeClass('d-none');
});
$(".step_7_timeline-badge-5A").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_7_timeline-badge-5A").addClass('active');
	$(".step_7").addClass('d-none');
	$(".step_7_5A").removeClass('d-none');
});
$(".step_7_timeline-badge-5B").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_7_timeline-badge-5B").addClass('active');
	$(".step_7").addClass('d-none');
	$(".step_7_5B").removeClass('d-none');
});
$(".step_7_timeline-badge-6").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_7_timeline-badge-6").addClass('active');
	$(".step_7").addClass('d-none');
	$(".step_7_6").removeClass('d-none');
});

// Step 8
$(".step_8_timeline-badge-1").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_8_timeline-badge-1").addClass('active');
	$(".step_8").addClass('d-none');
	$(".step_8_1").removeClass('d-none');
});
$(".step_8_timeline-badge-2").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_8_timeline-badge-2").addClass('active');
	$(".step_8").addClass('d-none');
	$(".step_8_2").removeClass('d-none');
});
$(".step_8_timeline-badge-3").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_8_timeline-badge-3").addClass('active');
	$(".step_8").addClass('d-none');
	$(".step_8_3").removeClass('d-none');
});

// Step 9
$(".step_9_timeline-badge-1").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_9_timeline-badge-1").addClass('active');
	$(".step_9").addClass('d-none');
	$(".step_9_1").removeClass('d-none');
});
$(".step_9_timeline-badge-2").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_9_timeline-badge-2").addClass('active');
	$(".step_9").addClass('d-none');
	$(".step_9_2").removeClass('d-none');
});
$(".step_9_timeline-badge-3").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_9_timeline-badge-3").addClass('active');
	$(".step_9").addClass('d-none');
	$(".step_9_3").removeClass('d-none');
});

// Step 10
$(".step_10_timeline-badge-1").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_10_timeline-badge-1").addClass('active');
	$(".step_10").addClass('d-none');
	$(".step_10_1").removeClass('d-none');
});
$(".step_10_timeline-badge-2").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_10_timeline-badge-2").addClass('active');
	$(".step_10").addClass('d-none');
	$(".step_10_2").removeClass('d-none');
});
$(".step_10_timeline-badge-3").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_10_timeline-badge-3").addClass('active');
	$(".step_10").addClass('d-none');
	$(".step_10_3").removeClass('d-none');
});

// Step 11
$(".step_11_timeline-badge-1").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_11_timeline-badge-1").addClass('active');
	$(".step_11").addClass('d-none');
	$(".step_11_1").removeClass('d-none');
});
$(".step_11_timeline-badge-2").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_11_timeline-badge-2").addClass('active');
	$(".step_11").addClass('d-none');
	$(".step_11_2").removeClass('d-none');
});
$(".step_11_timeline-badge-3").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_11_timeline-badge-3").addClass('active');
	$(".step_11").addClass('d-none');
	$(".step_11_3").removeClass('d-none');
});
$(".step_11_timeline-badge-4").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_11_timeline-badge-4").addClass('active');
	$(".step_11").addClass('d-none');
	$(".step_11_4").removeClass('d-none');
});
$(".step_11_timeline-badge-5A").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_11_timeline-badge-5A").addClass('active');
	$(".step_11").addClass('d-none');
	$(".step_11_5A").removeClass('d-none');
});
$(".step_11_timeline-badge-5B").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_11_timeline-badge-5B").addClass('active');
	$(".step_11").addClass('d-none');
	$(".step_11_5B").removeClass('d-none');
});
$(".step_11_timeline-badge-6").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_11_timeline-badge-6").addClass('active');
	$(".step_11").addClass('d-none');
	$(".step_11_6").removeClass('d-none');
});

// Step12
$(".step_12_timeline-badge-1").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_12_timeline-badge-1").addClass('active');
	$(".step_12").addClass('d-none');
	$(".step_12_1").removeClass('d-none');
});
$(".step_12_timeline-badge-2").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_12_timeline-badge-2").addClass('active');
	$(".step_12").addClass('d-none');
	$(".step_12_2").removeClass('d-none');
});
$(".step_12_timeline-badge-3").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_12_timeline-badge-3").addClass('active');
	$(".step_12").addClass('d-none');
	$(".step_12_3").removeClass('d-none');
});
$(".step_12_timeline-badge-4").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_12_timeline-badge-4").addClass('active');
	$(".step_12").addClass('d-none');
	$(".step_12_4").removeClass('d-none');
});
$(".step_12_timeline-badge-5").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_12_timeline-badge-5").addClass('active');
	$(".step_12").addClass('d-none');
	$(".step_12_5").removeClass('d-none');
});
$(".step_12_timeline-badge-6A").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_12_timeline-badge-6A").addClass('active');
	$(".step_12").addClass('d-none');
	$(".step_12_6A").removeClass('d-none');
});
$(".step_12_timeline-badge-6B").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_12_timeline-badge-6B").addClass('active');
	$(".step_12").addClass('d-none');
	$(".step_12_6B").removeClass('d-none');
});
$(".step_12_timeline-badge-7").click(function() {
	$(".timeline-badge").removeClass('active');
	$(".step_12_timeline-badge-7").addClass('active');
	$(".step_12").addClass('d-none');
	$(".step_12_7").removeClass('d-none');
});