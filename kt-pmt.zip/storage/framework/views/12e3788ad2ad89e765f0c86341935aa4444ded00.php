

<?php $__env->startSection('title', 'Add Points - Khit Thit '); ?>
<style type="text/css">
	.form-box {
		border: 2px solid #CB9D4C;
		border-radius: 10px;
		padding: 30px 20px;
	}
	.form-input-txt {
		border: 0.5px solid #CB9D4C !important;
		border-radius: 50px !important;
	}
	.check-number-btn {
		border-radius: 50px !important;
		background-color: #fff;
		border-color: #23225C !important;
		color: #23225C !important;
	}
	.check-number-btn:hover {
		background-color: #23225C !important;
		border-color: #23225C !important;
		color: #fff !important;
	}
</style>
<?php $__env->startSection('content'); ?>
<div class="layout-wrapper layout-content-navbar">
	<div class="layout-container">
	<?php echo $__env->make('layouts.admin_sidebar', ['page'=>'AddPoint'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="layout-page" style="background-color: #fff">
        <?php echo $__env->make('layouts.nav', ['nav'=>'Add Point', 'page'=>'AddPoint'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <br>
            <div class="content-wrapper" style="background-color:#fff">
				<div class="container-xxl flex-grow-1 container-p-y">
					<div class="form-box">
						<div class="row">
							<form id="formAuthentication" class="mb-3" action="<?php echo e(url('/admin/addpoints/check-number')); ?>" method="POST">
								<?php echo e(csrf_field()); ?>

								<div class="row mb-3">
									<div class="col-md-3">
										<label for="phone" class="form-label">Phone</label>
										<input type="text" class="form-control form-input-txt" id="phone" name="phone" placeholder="09 123 456 789" required />
									</div>
									<div class="col-md-3">
										<label for="phone" class="form-label">&nbsp;</label>
										<button type="submit" class="btn check-number-btn btn-outline-primary d-grid w-30" >Check Number</button>
									</div>
                                </div>
							</form>
						</div>
					</div>
				</div>
			</div>
        
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kt-pmt\resources\views/admin/addpoints/list.blade.php ENDPATH**/ ?>