<?php if(count($errors)): ?>
	<div class="alert alert-danger" role="alert" style="width: 100%;">
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		
			<p>
				<?php echo $error; ?>

			</p>
		
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</div>
<?php endif; ?>

<?php if(session('error')): ?>
	<div class="alert alert-danger" role="alert" style="width: 100%;">
		<?php echo e(session('error')); ?>

	</div>
<?php endif; ?>

<?php if(session('success')): ?>
	<div class="alert alert-success" role="alert" style="width: 100%;margin-bottom: 10px;">
		<?php echo e(session('success')); ?>

	</div>
<?php endif; ?>

<?php if(session('info')): ?>
	<div class="alert" role="alert" style="width: 100%;background-color: #888e91;color: #fff;border-color: #888e91;">
		<?php echo e(session('info')); ?>

	</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\kt-pmt\resources\views/layouts/message.blade.php ENDPATH**/ ?>