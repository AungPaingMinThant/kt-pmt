

<?php $__env->startSection('title', 'Member List – Khit Thit'); ?>
<style type="text/css">
	.flr {
		float: right;
	}
	.card {
		box-shadow: none !important;
	}
</style>
<?php $__env->startSection('content'); ?>
<div class="layout-wrapper layout-content-navbar">
   	<div class="layout-container">
		<?php echo $__env->make('layouts.admin_sidebar', ['page'=>'MemberList'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div class="layout-page" style="background-color:#fff">
			<?php echo $__env->make('layouts.nav', ['nav'=>'Member List', 'page'=>'Page'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<div class="content-wrapper">
				<div class="container-xxl flex-grow-1 container-p-y">
					<div class="row">
						<!-- <div class="col-12 text-right">
							<label class="" for="show_entries">All(22)</label>
							<input type="date" class="form-control_date rounded" placeholder="mm-dd-yy" aria-label="Search" aria-describedby="search-addon" />&nbsp;&nbsp;
							<input type="search" class="form-control_name rounded" placeholder="Search by name" aria-label="Search" aria-describedby="search-addon" />
							<a href="<?php echo e(url('/admin/member/filter/')); ?>">
								<button type="button" class="btn  btn-outline-primary_filter flr">Filter</button>
							</a>
						</div> -->
    					
						<div class="col-12">
							<div class="card mt-4">
								<div class="table-responsive text-nowrap">
									<table class="table">
										<thead>
											<tr>
												<th width="20">No</th>
												<th>Name</th>
												<th>Membership Date</th>
												<th>Member Point</th>
												<th>Actions</th>
											</tr>
										</thead>
										
										<tbody class="table-border-bottom-0">
											<?php $member_count=1; ?>
											<?php $__currentLoopData = $member_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<tr>
													<td><?php echo e($member_count); ?></td>
													<td><?php echo e($member->name); ?></td>
													<td><?php echo date('M-j-Y', strtotime($member->created_at)); ?></td>
													<td><?php echo e($member->member_point); ?></td>
													<td>
														<a href="<?php echo e(url('/admin/member/detail/'. $member->id)); ?>">
															<button type="button" class="btn btn-outline-primary_list">
																View Detail
															</button>
														</a>
														<a href="<?php echo e(url('/admin/member/edit/'. $member->id)); ?>">
															<button type="button" class="btn btn-outline-primary_list">
																Edit
															</button>
														</a>
														<div class="modal fade" id="backDropModal_<?php echo e($member->id); ?>" data-bs-backdrop="static" tabindex="-1">
															<div class="modal-dialog modal-dialog-centered">
																<form class="modal-content" action="<?php echo e(url('')); ?>" method="post">
																	<?php echo e(csrf_field()); ?>

																	<div class="modal-header">					
																		<button
																		type="button"
																		class="btn-close"
																		data-bs-dismiss="modal"
																		aria-label="Close"
																		></button>
																	</div>
																	<div class="modal-body">
																		<div class="row">
																			<h5 class="modal-title" id="backDropModalTitle">Are you sure want to delete this Member?</h5>
																			<div class="col mb-3">
																				<input
																				type="hidden"
																				name="atm_id"
																				class="form-control"
																				value="<?php echo e($member->id); ?>"
																				/>
																			</div>
																		</div>
																	</div>
																	<div class="modal-footer">
																		<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
																		Close
																		</button>
																		<button type="submit" class="btn btn-primary">Delete</button>
																	</div>
																</form>
															</div>
														</div>
													</td>
												</tr>
												<?php
													$member_count = $member_count+1;
												?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kt-pmt\resources\views/admin/member/list.blade.php ENDPATH**/ ?>