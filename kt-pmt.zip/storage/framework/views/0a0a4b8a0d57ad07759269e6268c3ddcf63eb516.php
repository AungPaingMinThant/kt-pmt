

<?php $__env->startSection('title', 'Member Detail – Khit Thit'); ?>
<style type="text/css">
	.form-label {
		text-transform: capitalize !important;
	}
	.form-box {
		border: 2px solid #CB9D4C;
		border-radius: 10px;
		padding: 30px 20px;
	}
	.edit-btn {
		padding: 7px 25px !important;
		float: right;
		border-radius: 50px !important;
		background-color: #fff;
		border-color: #23225C !important;
		color: #23225C !important;
	}
	.edit-btn:hover {
		background-color: #23225C !important;
		border-color: #23225C !important;
		color: #fff !important;
	}
</style>
<?php $__env->startSection('content'); ?>
	<div class="layout-wrapper layout-content-navbar">
	   	<div class="layout-container">
			<?php echo $__env->make('layouts.admin_sidebar', ['page'=>'MemberList'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<div class="layout-page" style="background-color:#fff">
				<?php echo $__env->make('layouts.nav', ['nav'=>'Member Detail', 'page'=>'MemberList'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

				<div class="content-wrapper">
					<div class="container-xxl flex-grow-1 container-p-y">
						<div class="">
							<a href="<?php echo e(url('admin/member')); ?>" style="cursor: pointer;"><label style="cursor: pointer;"><i class="menu-icon tf-icons bx bx-chevrons-left"></i> Back to list</label></a>
							<div class="space-20"></div>
							<div class="row mb-3">
								<div class="col-md-2">
									<label for="employee_id" class="form-label">Member ID</label>
									<div><?php echo $member_list->employee_id; ?></div>
								</div>
								<div class="col-md-2">
									<label for="name" class="form-label">Name</label>
									<div><?php echo $member_list->name; ?></div>
								</div>
								<div class="col-md-2">
									<label for="phone" class="form-label">Phone</label>
									<div><?php echo $member_list->phone; ?></div>
								</div>
								<div class="col-md-2">
									<label for="member_point" class="form-label">Total Points</label>
									<div><?php echo $member_list->member_point; ?>&nbsp;Pts</div>
								</div>
								<div class="col-md-4 text-right">
									<a href="<?php echo e(url('/admin/member/edit/'. $member_list->id)); ?>">
										<button type="button" class="btn btn-outline-primary_list edit-btn">Edit</button>
									</a>
								</div>
							</div>
							
							<div class="space-20"></div>

							<h5>Point History</h5>
							<div class="col-xl">
								<div class="card mb-1">
									<div class="card-body_detail">
										<form class="mb-3" action="<?php echo e(url('/admin/member/edit/{member_id}')); ?>" method="POST" id="fx_form" enctype="multipart/form-data" >
											<?php echo e(csrf_field()); ?>

											<div class="col-12">
												<div class="row mb-3">
													<div class="col-md-1">
														<label for="employee_id" class="form-label">Date</label>		
													</div>
													<div class="col-md-1">
														<label for="name" class="form-label">Point in</label>
													</div>
													<div class="col-md-1">
														<label for="phone" class="form-label">Redeem</label>
													</div>
													<div class="col-md-1">
														<label for="member_point" class="form-label">Member ID</label>
													</div>
												</div>
												<?php $__currentLoopData = $point_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<div class="row mb-3 border-9">
														<div class="col-md-1">
															<div><?php echo date('M-j-Y', strtotime($point->created_at)); ?></div>
														</div>
														<div class="col-md-1">
															<div>+<?php echo $point->point_in; ?></div>
														</div>
														<div class="col-md-1">
															<div>-<?php echo $point->redeem; ?></div>
														</div>
														<div class="col-md-1">
															<div><?php echo $point->employee_id; ?>&nbsp;</div>
														</div>
													</div>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</div>
											</div>	
										</form>	
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kt-pmt\resources\views/admin/member/detail.blade.php ENDPATH**/ ?>