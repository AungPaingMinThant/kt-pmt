$("#banner_img").change(function() {
	$("#banner_img_old").val('');
});






